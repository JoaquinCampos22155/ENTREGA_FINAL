import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import useOrder from '../../Hooks/useOrder'; // Asegúrate de ajustar la ruta de importación

const ShippingForm = ({ email, price, discount, cartData }) => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    avenida: '',
    numero: '',
    colonia: '',
    zona: '',
  });

  const [errors, setErrors] = useState({});
  const [formSubmitted, setFormSubmitted] = useState(false);
  const navigate = useNavigate();
  const { addClient, createOrder, addOrderDetails, loading, error } = useOrder(); // Añadimos `addOrderDetails` desde el hook

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
    if (formSubmitted) {
      validateForm();
    }
  };

  const validateForm = () => {
    const newErrors = {};
    Object.keys(formData).forEach((key) => {
      if (!formData[key]) {
        newErrors[key] = `${key} is required`;
      }
    });
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setFormSubmitted(true);
    if (validateForm()) {
      const clientData = {
        nombre: `${formData.firstName} ${formData.lastName}`,
        email: email,
        direccion: `${formData.zona}, ${formData.avenida}, ${formData.colonia}, ${formData.numero}`,
        contra: '',
      };

      // Agregar cliente
      const client = await addClient(clientData);

      if (client) {
        console.log('Cliente creado:', client);

        // Crear una nueva orden con el id del cliente recién creado
        const orderData = {
          fechaCreacion: new Date().toISOString(), // Fecha actual
          estado: 'Preparacion en curso',
          id_cliente: client.id_cliente, // Utiliza el ID del cliente recién creado
        };

        const order = await createOrder(orderData);
        if (order) {
          console.log('Orden creada:', order);

          // Guardar el id de la orden creada para usarlo en ordenes-detalles
          const idOrden = order.id_orden;

          // Iterar sobre cartData para enviar cada producto a ordenes-detalles
          for (const product of cartData) {
            const orderDetailsData = {
              id_orden: idOrden,
              id_producto: product.id, // ID del producto desde cartData
              cantidad: product.quantity, // Cantidad desde cartData
              precioPorUnidad: product.price, // Precio desde cartData
            };

            // Agregar detalles de la orden
            await addOrderDetails(orderDetailsData);
          }

          // Redirigir después de completar todos los detalles de la orden
          navigate('/'); // Redirigir a la ruta principal o a otra ruta deseada
        }
      }
    }
  };

  useEffect(() => {
    const inputs = document.querySelectorAll('input, select');

    inputs.forEach((input) => {
      input.oninvalid = function (e) {
        e.target.setCustomValidity('Este espacio debe ser llenado');
      };

      input.oninput = function (e) {
        e.target.setCustomValidity('');
      };
    });
  }, []);

  return (
    <form className="shipping-form" onSubmit={handleSubmit}>
      <input
        type="text"
        name="firstName"
        placeholder="First Name"
        value={formData.firstName}
        onChange={handleInputChange}
        className={errors.firstName ? 'error' : ''}
        required
      />
      <input
        type="text"
        name="lastName"
        placeholder="Last Name"
        value={formData.lastName}
        onChange={handleInputChange}
        className={errors.lastName ? 'error' : ''}
        required
      />
      <input
        type="text"
        name="avenida"
        placeholder="Avenida"
        value={formData.avenida}
        onChange={handleInputChange}
        className={errors.avenida ? 'error' : ''}
        required
      />
      <input
        type="text"
        name="numero"
        placeholder="Número de Casa/Apartamento"
        value={formData.numero}
        onChange={handleInputChange}
        className={errors.numero ? 'error' : ''}
        required
      />
      <input
        type="text"
        name="colonia"
        placeholder="Colonia"
        value={formData.colonia}
        onChange={handleInputChange}
        className={errors.colonia ? 'error' : ''}
        required
      />
      <select
        name="zona"
        value={formData.zona}
        onChange={handleInputChange}
        className={errors.zona ? 'error' : ''}
        required
      >
        <option value="">Seleccionar Zona</option>
        {[...Array(22)].map((_, i) => (
          <option key={i} value={`zona ${i + 1}`}>{`Zona ${i + 1}`}</option>
        ))}
      </select>
      <button type="submit" className="submit-button">Continue</button>
      {Object.keys(errors).length > 0 && (
        <div className="error-message">All fields are required.</div>
      )}
    </form>
  );
};

export default ShippingForm;
