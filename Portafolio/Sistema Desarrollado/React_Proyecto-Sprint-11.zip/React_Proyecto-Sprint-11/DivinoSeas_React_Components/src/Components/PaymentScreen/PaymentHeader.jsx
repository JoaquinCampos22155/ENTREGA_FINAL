import React from 'react';

const PaymentHeader = () => {
  return (
    <header className="payment-header">
      <h1>Payment Information</h1>
    </header>
  );
};

export default PaymentHeader;
