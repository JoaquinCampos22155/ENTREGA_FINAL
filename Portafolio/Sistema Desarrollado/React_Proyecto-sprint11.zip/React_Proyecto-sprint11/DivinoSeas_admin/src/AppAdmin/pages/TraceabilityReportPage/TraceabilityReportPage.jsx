// TraceabilityReportPage.js
import React from 'react';
import AuditReport from '../../Componentsadmins/AuditReport';

const TraceabilityReportPage = () => {
  return (
    <div>
      <AuditReport />
    </div>
  );
};

export default TraceabilityReportPage;
