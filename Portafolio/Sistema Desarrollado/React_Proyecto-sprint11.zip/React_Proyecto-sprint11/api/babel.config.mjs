export default {
  presets: ["@babel/preset-env"],
};
