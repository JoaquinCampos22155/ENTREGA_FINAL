import express from "express";
import multer from "multer";
import {
  loginUser,
  getAllUsers,
  getUserById,
  createUser,
  updateUser,
  deleteUser,
} from "../services/userService.js";
import authMiddleware from "../authMiddleware.js";

const JWT_SECRET = process.env.JWT_SECRET;

const router = express.Router();

// Configuración de multer para manejar la subida de imágenes en memoria
const storage = multer.memoryStorage();
const upload = multer({ storage });

// Middleware de validación para los datos del usuario
function validacionUsuario(req, res, next) {
  const { username, email, password_hashed, is_admin, role } = req.body;
  if (
    !username ||
    !email ||
    !password_hashed ||
    typeof is_admin === "undefined" ||
    !role
  ) {
    return res.status(400).json({
      error:
        "Faltan o son inválidos el nombre de usuario, el correo electrónico, la contraseña, el estado de administrador o el rol.",
    });
  }
  next();
}

// Obtener todos los usuarios
router.get("/", authMiddleware, async (req, res) => {
  const users = await getAllUsers();
  res.status(200).json(users);
});

// Obtener un usuario por ID
router.get("/:id", authMiddleware, async (req, res) => {
  const { id } = req.params;
  const user = await getUserById(id);
  if (user) {
    res.status(200).json(user);
  } else {
    res.status(404).json({ message: "Usuario no encontrado" });
  }
});

// Crear un nuevo usuario
// Crear un nuevo usuario (ruta de registro)
// userRoutes.js
router.post(
    "/",
    upload.single("imagen"),
    validacionUsuario,
    async (req, res) => {
      const { username, email, password_hashed, is_admin, role } = req.body;
      const imagen = req.file ? req.file.buffer : null; // Obtener la imagen si está disponible
  
      try {
        const isAdminValue = is_admin ? 1 : 0;
        const { success, id_user, error } = await createUser(
          username,
          email,
          password_hashed,
          isAdminValue,
          role,
          imagen
        );
  
        if (success) {
          // Generar token con los datos del nuevo usuario
          const token = jwt.sign(
            { id_user, username, email },
            process.env.JWT_SECRET,
            { expiresIn: "1h" }
          );
  
          return res.status(201).json({
            success: true,
            message: "Usuario creado con éxito",
            userId: id_user,
            token, // Retorna el token en la respuesta
          });
        } else {
          console.error("Error al crear el usuario", error);
          return res.status(500).json({
            success: false,
            message: "Error al crear el usuario",
            error,
          });
        }
      } catch (error) {
        console.error(error);
        return res
          .status(500)
          .json({ success: false, message: "Error Interno del Servidor" });
      }
    }
  );
  
  

// Actualizar un usuario existente
router.put(
  "/:id",
  authMiddleware,
  upload.single("imagen"),
  validacionUsuario,
  async (req, res) => {
    const { id } = req.params;
    const { username, email, password_hashed, is_admin, role } = req.body;
    const imagen = req.file ? req.file.buffer : null;

    try {
      const isAdminValue = is_admin ? 1 : 0;
      const result = await updateUser(
        id,
        username,
        email,
        password_hashed,
        isAdminValue,
        role,
        imagen
      );

      if (result.affectedRows > 0) {
        return res
          .status(200)
          .json({ success: true, message: "Usuario actualizado con éxito" });
      } else {
        throw new Error(`Error al actualizar el usuario con ID: ${id}`);
      }
    } catch (error) {
      console.error(error);
      return res.status(500).json({ message: "Error Interno del Servidor" });
    }
  }
);

// Eliminar un usuario
router.delete("/:id", authMiddleware, async (req, res) => {
  const { id } = req.params;
  try {
    await deleteUser(id);
    res.status(204).send();
  } catch (error) {
    console.error("Error al eliminar el usuario:", error);
    res.status(500).json({ message: "Error Interno del Servidor" });
  }
});

router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const result = await loginUser(email, password);

  if (result.success) {
    const { id_user, username, email, role } = result.user; // Asegúrate de incluir `id_user`
    const token = result.token;

    console.log("Datos enviados al cliente:", { id_user, username, email, role }); // Debug
    res.json({ token, user: { id_user, username, email, role } }); // Devuelve el objeto completo
  } else {
    res.status(401).json({ message: result.message || "Error de autenticación" });
  }
});



export default router;
