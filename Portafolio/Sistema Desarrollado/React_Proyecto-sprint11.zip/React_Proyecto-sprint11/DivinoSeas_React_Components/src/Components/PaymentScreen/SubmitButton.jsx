import React from 'react';

const SubmitButton = () => {
  return <button type="submit" className="submit-button">Continue to Shipping Method</button>;
};

export default SubmitButton;
